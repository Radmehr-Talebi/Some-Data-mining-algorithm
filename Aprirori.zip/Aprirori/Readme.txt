The Defualt value for minsupport is 2500 for faster output however you can take it as an input by uncommenting the lines for input(line 143)
The threshold for Confidence is 10, which you can change it in line 175
output file is exactly as the printed text in terminal.